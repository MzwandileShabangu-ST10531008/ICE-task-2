package com.mycompany.progice2;
import java.util.Scanner;
public class ProgICE2
{
    public static void main(String[] args)
    {
       Scanner scan = new Scanner(System.in);
       
       String name;
       String surname;
       int age;
       
       name = "Jack";
       surname = "Khoza";
       age = 25;
       
       System.out.println("Enter your name : ");
       name = scan.nextLine();
       
       System.out.println("Enter your surname : ");
       surname = scan.nextLine();
       
       System.out.println("Enter your age : ");
       age = scan.nextInt();
       
       boolean isJack = checkIdentity(name, surname, age);
       
       if(isJack)
       {
           System.out.println("It is Jack");
       }
       else
       {
           System.out.println("This is not Jack");
       }
    }
    
    public static boolean checkIdentity(String name, String surname, int age)
    {
        return name.equals("Jack") && surname.equals("Khoza") && age == 25;
    }
}
